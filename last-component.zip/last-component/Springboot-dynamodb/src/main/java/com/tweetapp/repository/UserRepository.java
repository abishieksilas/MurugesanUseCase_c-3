package com.tweetapp.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.tweetapp.entity.Users;

@Repository
public class UserRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void newUserRegistration(Users user) {
		dynamoDBMapper.save(user);
	}

	public Users findByEmail(String email) {
		return dynamoDBMapper.load(Users.class, email);
	}

	public void updatePassword(String username, Users user) {
		dynamoDBMapper.save(user, new DynamoDBSaveExpression().withExpectedEntry("loginId",
				new ExpectedAttributeValue(new AttributeValue().withS(username))));
	}

	public List<Users> searchUserByName(String userName) {

		HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
		eav.put(":v1", new AttributeValue().withS(userName));

		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
				.withFilterExpression("begins_with(loginId,:v1)").withExpressionAttributeValues(eav);

		List<Users> users = dynamoDBMapper.scan(Users.class, scanExpression);

		return users;

	}

	public List<Users> getAllUser() {

		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
		List<Users> iList = dynamoDBMapper.scan(Users.class, scanExpression);
		return iList;
	}
}
