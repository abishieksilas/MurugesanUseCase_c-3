package com.tweetapp.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.tweetapp.entity.Tweets;

@Repository
public class TweetRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public List<Tweets> getAllUserTweets() {
		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
		List<Tweets> iList = dynamoDBMapper.scan(Tweets.class, scanExpression);
		return iList;
	}

	public void deleteUserTweet(String tweetId) {
		Tweets tweet = dynamoDBMapper.load(Tweets.class, tweetId);
		dynamoDBMapper.delete(tweet);
	}
	
	public Tweets getTweetById(String tweetId){
		return dynamoDBMapper.load(Tweets.class, tweetId);
	}
 
	public void save(Tweets tweet){
		dynamoDBMapper.save(tweet);
	}
	
	public List<Tweets> findByLoginId(String loginId){
		HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
		eav.put(":v1", new AttributeValue().withS(loginId));

		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
		    .withFilterExpression("begins_with(loginId,:v1)")
		    .withExpressionAttributeValues(eav);
        List<Tweets> users = dynamoDBMapper.scan(Tweets.class,scanExpression);
		
		return users;
		
	}
}
