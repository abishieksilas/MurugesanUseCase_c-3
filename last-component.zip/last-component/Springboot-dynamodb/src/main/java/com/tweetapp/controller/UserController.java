package com.tweetapp.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.dto.UsersDTO;
import com.tweetapp.entity.Users;
import com.tweetapp.repository.UserRepository;
import com.tweetapp.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;
	@Autowired
	UserRepository userRepository;

	@GetMapping("/api/v1.0/tweets/{username}/forgot")
	public ResponseEntity<?> forgotPassword(@PathVariable String username, @RequestBody Users user) throws Exception {

		userService.forgotUserPassword(username, user);
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@PostMapping("/api/v1.0/tweets/register")
	public ResponseEntity<?> newUserRegistration(@Valid @RequestBody UsersDTO user) {
		userService.userRegistration(user);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("/api/v1.0/tweets/users/all")
	public ResponseEntity<?> getAllUsers() {

		return new ResponseEntity<>(userRepository.getAllUser(), HttpStatus.OK);

	}

	@GetMapping("/api/v1.0/tweets/user/search/{username}")
	public ResponseEntity<?> searchUserByUserName(@PathVariable String username) {

		return new ResponseEntity<>(userRepository.searchUserByName(username), HttpStatus.OK);

	}

}
