package com.tweetapp.service;

import java.util.ArrayList;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.UsersDTO;
import com.tweetapp.entity.Users;
import com.tweetapp.exception.ResourceAlreadyExistsException;
import com.tweetapp.exception.ResourceNotFoundException;

import com.tweetapp.repository.UserRepository;

@Service
public class UserService implements UsersService {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	UserRepository userRegistration;

	public void userService(BCryptPasswordEncoder bCryptPasswordEncoder) {
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}

	public void userRegistration(UsersDTO data) {

		ModelMapper modelMapper = new ModelMapper();

		Users userData = modelMapper.map(data, Users.class);

		Users user = userRegistration.findByEmail(userData.getLoginId());
		if (user != null) {
			throw new ResourceAlreadyExistsException("Already Exists");
		}
		userData.setPassword(bCryptPasswordEncoder.encode(data.getPassword()));

		userRegistration.newUserRegistration(userData);
	}

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		Users user = userRegistration.findByEmail(userName);
		if (user == null)
			throw new UsernameNotFoundException(userName);
		return new User(user.getLoginId(), user.getPassword(), true, true, true, true, new ArrayList<>());
	}

	public Users getDetailsByEmail(String userName) {
		Users user = userRegistration.findByEmail(userName);
		if (user == null)
			throw new ResourceNotFoundException("Resource Not Found");
		return user;
	}

    public void forgotUserPassword(String username, Users user) throws Exception {
    
       userRegistration.updatePassword(username, user);
    
    
    } 

}
