package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.ReplyTweet;
import com.tweetapp.dto.TweetReply;
import com.tweetapp.dto.TweetsDTO;
import com.tweetapp.entity.Tweets;
import com.tweetapp.exception.TweetNotFoundException;
import com.tweetapp.repository.TweetRepository;


@Service
public class TweetsService {

	@Autowired
	TweetRepository tweetsRepo;

	public void updateUserTweet(String username, String id, TweetsDTO data) throws Exception {

		try {
			ModelMapper modelMapper = new ModelMapper();
			Tweets userTweet = modelMapper.map(data, Tweets.class);
			data.setTweetId(id);
			data.setLoginId(username);
			tweetsRepo.save(userTweet);
		} catch (Exception e) {
			throw new TweetNotFoundException();
		}
	}

	public List<TweetsDTO> getTweetsOfAllUser() {

		List<Tweets> userTweet = tweetsRepo.getAllUserTweets();
		if (userTweet == null)
			throw new TweetNotFoundException();
		ModelMapper modelMapper = new ModelMapper();
		List<TweetsDTO> userTweets = userTweet.stream().map(users -> modelMapper.map(users, TweetsDTO.class))
				.collect(Collectors.toList());
		return userTweets;
	}

	public void deleteUserTweet(String tweetId) {
		//long result = -1;

		tweetsRepo.deleteUserTweet(tweetId);

		//if (result == 0)
	//		throw new TweetNotFoundException("The requested tweet does not found");

	}

	public void likeUserTweet(String tweetId, String userName) {

		Tweets tweet = tweetsRepo.getTweetById(tweetId);
		if (tweet == null)
			throw new TweetNotFoundException("The requested tweet does not found");
		List<String> likes = tweet.getLikes();
		if(likes!=null){
		likes.add(userName);
		tweet.setLikes(likes);
		}
		else{
			List<String> added = new ArrayList<>();
			added.add(userName);
			tweet.setLikes(added);
		}
		int like  = tweet.getLikeCount();
		like = like + 1;
		tweet.setLikeCount(like);
		
		tweetsRepo.save(tweet);

	}

	public void replyUserTweet(String username, String tweetId, ReplyTweet replyTweet) {

		Tweets tweet = tweetsRepo.getTweetById(tweetId);
		if (tweet == null)
			throw new TweetNotFoundException();
		TweetReply tweetReply = new TweetReply();
		tweetReply.setUsername(username);
		tweetReply.setReply(replyTweet.getReply());
		if(tweet.getReply() != null)
		tweet.getReply().add(tweetReply);
		else{
			List<TweetReply> reply = new ArrayList<>();
			reply.add(tweetReply);
		 tweet.setReply(reply);
		 }
		tweetsRepo.save(tweet);

	}

	public List<TweetsDTO> findTweetsByUserName(String userName) {
		ModelMapper modelMapper = new ModelMapper();
		List<Tweets> userTweet = tweetsRepo.findByLoginId(userName);
		if (userTweet == null)
			throw new TweetNotFoundException();
		List<TweetsDTO> userTweets = userTweet.stream().map(users -> modelMapper.map(users, TweetsDTO.class))
				.collect(Collectors.toList());
		return userTweets;
	}

	public void postUserTweets(TweetsDTO tweet) {
		UUID uuid = UUID.randomUUID();
		ModelMapper modelMapper = new ModelMapper();
		Tweets userTweet = modelMapper.map(tweet, Tweets.class);
		userTweet.setTweetId(uuid.toString());
	   tweetsRepo.save(userTweet);
	}

}
