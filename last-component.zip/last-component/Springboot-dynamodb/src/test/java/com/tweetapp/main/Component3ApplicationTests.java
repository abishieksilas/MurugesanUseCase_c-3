package com.tweetapp.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Component3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
