import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.css']
})
export class PasswordResetComponent implements OnInit {

  constructor(private http: HttpClient) { }

    httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'}),
    observe: 'response' as 'response'
  };

  loginId: string;
  verificationCode: string;
  password: string;

  ngOnInit(): void {
  }

   changePassword(){
     this.http.post('https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/users/password/reset',{"loginId" : this.loginId, "code": this.verificationCode, "password": this.password}).subscribe(
        (data: any) => {
         console.log(data);
        });
   }
}
