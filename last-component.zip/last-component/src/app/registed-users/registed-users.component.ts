import { Component, OnInit } from '@angular/core';
import {UserService} from '../service/user.service';

@Component({
  selector: 'app-registed-users',
  templateUrl: './registed-users.component.html',
  styleUrls: ['./registed-users.component.css']
})
export class RegistedUsersComponent implements OnInit {

  constructor(private userService: UserService) { }

  users:any;
  ngOnInit(): void {
   // this.users = [{"email": "murugesh"},{"email": "murugesan10"}]
   this.getUserData();
  }
getUserData(){
   this.userService.getallUser().subscribe((data: any) => {
    
          this.users = data["body"];
          console.log(data);
        },
        (error) => {
          console.log(error);
        }
      );

}
  
  

}
