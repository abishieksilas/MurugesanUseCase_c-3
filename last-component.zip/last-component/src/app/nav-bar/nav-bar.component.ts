import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor() { }
  loginStatus: boolean;
  status: boolean = true;
  login_id = localStorage.getItem('login_id');
  ngOnInit(): void {
    if (!!localStorage.getItem('token')) {
      this.loginStatus = true;
    } else this.loginStatus = false;
  }
  userLoginStatus() {
    if (!!localStorage.getItem('token')) return true;
    else return false;
  }

}
