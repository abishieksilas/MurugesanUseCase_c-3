export class ForgotPasswordModel{

    password:String;
    newPassword:String;
    confirmPassword:String;

}