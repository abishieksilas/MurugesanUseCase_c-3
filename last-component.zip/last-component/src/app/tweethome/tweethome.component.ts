import { Component, OnInit,  ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { UserService } from '../service/user.service';
@Component({
  selector: 'app-tweethome',
  templateUrl: './tweethome.component.html',
  styleUrls: ['./tweethome.component.css'],
})
export class TweethomeComponent implements OnInit {
  id: string = null;
  userReply: string;
  currentUser: string = localStorage.getItem('login_id');
  search: String;
  tweet = [];
  users = [];
  userTweet: String;
  tweetComment: boolean = false;
  tweetID: string;
  userReplyToTweet: String;
  toggle = false;
  likeId: String;
  retrieveResonse: any;
   twet = [];
mo=false;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private loginService: LoginService,
    private userService: UserService
  ) {}

  enableDisableRule(tweetId) {
    this.likeId = tweetId;
    if(!this.liketweetIdByUserCheck(tweetId))
    {
    this.userService.likeUserTweet(tweetId).subscribe((data: any) => {
      this.ngOnInit();
      this.tweet.forEach((tweet) => {
        if (tweet.tweetId == tweetId) {
          tweet.likeCount = tweet.likeCount + 1;
          return tweet;
        }
      });
    });
  }
  }
  postTweet(userTweet) {
    let body = {
      tweet: userTweet,
      date: new Date().toISOString(),
    };
    this.userService.postUserTweet(body).subscribe((res: any) => {
       this.ngOnInit();
     });
  }

  replyToTweet(tweetId, reply) {
    
    this.userService.postReply(tweetId, { reply }).subscribe((data: any) => {
      this.ngOnInit();
      this.userReplyToTweet = null;
    }),
      (error) => {
        console.log(error);
      };
  }
  deleteUserTweet(tweetId) {
    this.userService.deleteTweet(tweetId).subscribe((data: any) => {
      this.mo = true;
      this.content.open();
      console.log('success');
    });
  }
 
  getTweet() {
    if (this.id == null) {
      this.userService.getUserTweet().subscribe(
        (data: any) => {
          console.log(data["body"]);
         this.tweet = data["body"];
          this.likeIdTweetId();
        },
        (error) => {
          console.log(error.status);
        }
      );
    } else {
      let url = 'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/' + this.id;

      this.userService.getTweetById(url).subscribe(
        (data: any) => {
          console.log(data["body"]);
          this.tweet = data["body"];
          this.likeIdTweetId();
        },
        (error) => {
          console.log(error.status);
        }
      );
    }
  }

  tweetId(tweet) {
    console.log(tweet);
    this.tweetID = tweet;
  }
  



showModelBox(){
  return this.mo;
}
  likeIdTweetId(){

    this.tweet.filter(e =>{
      if(e.likes!=null || e.likes!= undefined){
      e.likes.forEach(element => {
        if(element == this.currentUser){
          console.log(e.tweetId);
        this.twet.push(e.tweetId);
      }
      });}
    });
  }
liketweetIdByUserCheck(tweetId){
let res = false;
 this.twet.forEach(e => {
    if(tweetId == e){
      res = true;
    }
  });
  return res;
}
  pageStatus() {
    if (this.id != null) {
      return false;
    } else if (this.id == undefined) return true;
  }
  homeButton() {
    this.router.navigateByUrl('/tweet/home');
  }
  @ViewChild('content') content: any;
  ngOnInit(): void {
    this.route.params.subscribe((paramsId) => {
      this.id = paramsId.username;
    });
    this.getTweet();
  }
}
