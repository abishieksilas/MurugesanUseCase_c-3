import { Component, OnInit } from '@angular/core';
import { LoginService} from '../service/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-verify-user',
  templateUrl: './verify-user.component.html',
  styleUrls: ['./verify-user.component.css']
})
export class VerifyUserComponent implements OnInit {

  constructor(private registrationService: LoginService, private router: Router) { }
  registrationCode:String;
  loginID: String;
  ngOnInit(): void {
  }

  verifyCode(){
    this.registrationService.userCodeVerification(this.registrationCode, this.loginID).subscribe(
      (res:any) =>{
        console.log(res);
        if(res.status == 200){
          this.router.navigateByUrl("/user/login")
        }
      }
    )
  }

}
