import { Component, OnInit } from '@angular/core';
import {UserService} from '../service/user.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  constructor(private userService : UserService) { }
   tweets:any
   users:any
  ngOnInit(): void {
     this.getUsers();
     this.getTweets();
  }

  getUsers(){
    this.userService.getallUser().subscribe((data: any) => {
      this.users = data["body"];
    },
    (error) => {
      console.log(error);
    }
  );
  }

  getTweets(){
    this.userService.getUserTweet().subscribe((data: any) => {
      this.tweets = data["body"];
      console.log(this.tweets);
    },
    (error) => {
      console.log(error);
    }
  );
  }
}
