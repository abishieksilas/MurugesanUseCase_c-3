import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { emailValidator } from '../shared/validation';
import jwt_decode, { JwtPayload } from 'jwt-decode'
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css'],
})
export class UserloginComponent {
  constructor(
    private router: Router,
    private loginService: LoginService,
    private fb: FormBuilder
  ) {}

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }
  token: string;
  show: boolean = false;
  status: string;
  flag:boolean = false;
  isAuthenticated(){
    return this.flag;
  }
  loginForm = this.fb.group({
    email: ['', [Validators.required]],
    password: ['', Validators.required],
  });

  onSubmit() {

    console.log(this.loginForm.value);
    
    this.loginService.loginUser(this.loginForm.value).subscribe((res:any)=>{
      this.token = res.body.authenticationResult.idToken; 
      let decoded_token = jwt_decode<JwtPayload>(this.token);
      localStorage.setItem("token", this.token);
      localStorage.setItem("login_id",decoded_token['cognito:username']);
      this.router.navigateByUrl('/tweet/home');
    },(error)=>{
      if(error.status == 400){
        this.flag = true;
      }
    })
    
  }
}
