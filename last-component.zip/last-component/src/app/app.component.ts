import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { LoginService } from './service/login.service';
import { TweethomeComponent } from './tweethome/tweethome.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Tweet-App';
  constructor(private fb: FormBuilder) {}

  loginStatus: boolean;
  result: any = [];
  status: boolean = true;


  ngOnInit() {
    if (!!localStorage.getItem('token')) {
      this.loginStatus = true;
    } else this.loginStatus = false;
  }

  userLoginStatus() {
    if (!!localStorage.getItem('token')) return true;
    else return false;
  }
}
