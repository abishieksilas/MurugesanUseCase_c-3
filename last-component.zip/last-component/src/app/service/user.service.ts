import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}

  username = localStorage.getItem('login_id');
  postUserTweet(body) {
    return this.http.post(
      'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/'+
        localStorage.getItem('login_id') +
        '/add',
      body,
      this.httpOptions
    );
  }
   httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' , 'Authorization': `${localStorage.getItem('token')}`,}),
    observe: 'response' as 'response'
  };

  getallUser() {
    return this.http.get<any>(
     
     // 'http://localhost:8080/api/v1.0/tweets/users/all',
      'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/users/all',

      this.httpOptions
    );
  }

  getUserTweet() {
    return this.http.get<any>(
      //'http://localhost:8080/api/v1.0/tweets/all',
      //this.requestOptions
      'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/all', this.httpOptions
    );
  }

  getTweetById(url) {
    return this.http.get<any>(url, this.httpOptions);
  }

  postReply(tweetId, body) {
    return this.http.post(
      ' https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/' +
        this.username +
        '/reply/' +
        tweetId,
      body, this.httpOptions
    );
  }

  updateTweet(tweetId, body) {
    return this.http.put(
      //'http://localhost:8080/api/v1.0/tweets/' +
        ' https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/'+
        this.username +
        '/update/' +
        tweetId,
      body,
      this.httpOptions
    );
  }

  deleteTweet(tweetId) {
    return this.http.delete(
      // 'http://localhost:8080/api/v1.0/tweets/' +
      'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/' +
        this.username +
        '/delete/' +
        tweetId,
        this.httpOptions
    );
  }

  likeUserTweet(tweetId) {

    return this.http.put(
      'https://sa6djbhtte.execute-api.us-west-1.amazonaws.com/dev/api/v1.0/tweets/' +
        this.username +
        '/like/' +
        tweetId,null,
      this.httpOptions
    );
  }
}
