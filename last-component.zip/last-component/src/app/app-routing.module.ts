import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuard } from './auth.guard';
import { TweethomeComponent } from './tweethome/tweethome.component';
import { RegistedUsersComponent } from './registed-users/registed-users.component';
import { HomePageComponent } from './home-page/home-page.component';
import { SignupComponent } from './signup/signup.component';
import { VerifyUserComponent } from './verify-user/verify-user.component';
import {PasswordResetComponent} from './password-reset/password-reset.component';

const routes: Routes = [
  { path: 'user/login', component: UserloginComponent },
  { path: 'user/registration', component: UserRegistrationComponent },
  { path: 'allusers', component: RegistedUsersComponent },
  { path: 'user/home', component:  HomePageComponent},
  {path: 'user/signup', component: SignupComponent},
  {
    path: 'password/reset',
    component: PasswordResetComponent,
    canActivate: [AuthGuard],
  },
  { path: 'user/logout', component: LogoutComponent, canActivate: [AuthGuard] },
  {
    path: 'tweet/home',
    component: TweethomeComponent,
    canActivate: [AuthGuard],
  },
   {
     path: 'verify/code',
    component: VerifyUserComponent
  },
  {
    path: 'allusers/:username',
    component: TweethomeComponent,  
    canActivate: [AuthGuard],
  },
  {
    path: 'tweet/home/:username',
    component: TweethomeComponent,  
    canActivate: [AuthGuard],
  },
  {
    path: ':username',
    component: TweethomeComponent,  
    canActivate: [AuthGuard],
  },
  
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
